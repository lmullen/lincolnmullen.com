# middlebury_amsterdam

Data and code from the Kress Foundation Digital Mapping and Art History 2014 Summer Institute.

Associated blog post: ["Artistic Attention in Amsterdam, 1550-1750"](http://matthewlincoln.net/2015/02/15/mapping-artistic-attention-in-amsterdam.html)

[![DOI](https://zenodo.org/badge/5105/mdlincoln/middlebury_amsterdam.svg)](http://dx.doi.org/10.5281/zenodo.15461)

***
[Matthew D. Lincoln](http://matthewlincoln.net) | University of Maryland, College Park
